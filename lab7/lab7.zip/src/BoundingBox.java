public class BoundingBox {
    double xmin;
    double xmax;
    double ymin;
    double ymax;
}
